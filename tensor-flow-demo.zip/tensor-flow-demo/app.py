import tensorflow as tf
tf.add(1, 2).numpy()
hello = tf.constant('Hello, TensorFlow!')
print(hello.numpy())